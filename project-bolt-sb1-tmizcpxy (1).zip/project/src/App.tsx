import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';
import VideoSection from './components/VideoSection';
import Trainers from './components/Trainers';
import TrainingCalendar from './components/Calendar';
import Partners from './components/Partners';
import Testimonials from './components/Testimonials';
import GovPrograms from './components/GovPrograms';
import Footer from './components/Footer';
import About from './pages/About';
import Consultation from './pages/Consultation';
import Formation from './pages/Formation';
import Chatbot from './components/Chatbot';

function App() {
  return (
    <div className="min-h-screen bg-primary-950">
      <Navbar />
      <Routes>
        <Route path="/" element={
          <main>
            <Hero />
            <VideoSection />
            <Services />
            <Trainers />
            <TrainingCalendar />
            <Partners />
            <Testimonials />
            <GovPrograms />
            <Footer />
          </main>
        } />
        <Route path="/about" element={<About />} />
        <Route path="/consultation" element={<Consultation />} />
        <Route path="/formation" element={<Formation />} />
        <Route path="/trainers" element={<Trainers />} />
      </Routes>
      <Chatbot />
    </div>
  );
}

export default App;