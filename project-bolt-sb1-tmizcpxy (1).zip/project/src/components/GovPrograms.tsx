import React from 'react';
import { Award, DollarSign, Building2, FileText, Briefcase, GraduationCap } from 'lucide-react';

const GovPrograms = () => {
  return (
    <section id="programs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Financement et Programmes Gouvernementaux
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Découvrez les aides financières disponibles pour votre formation en IA
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8">
            <Award className="h-12 w-12 text-blue-600" />
            <h3 className="mt-6 text-xl font-semibold text-gray-900">
              PACME
            </h3>
            <p className="mt-4 text-gray-600">
              Programme actions concertées pour le maintien en emploi. Subvention jusqu'à 100% 
              des dépenses admissibles pour la formation en IA.
            </p>
            <button className="mt-6 text-blue-600 font-medium hover:text-blue-700">
              En savoir plus →
            </button>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8">
            <DollarSign className="h-12 w-12 text-blue-600" />
            <h3 className="mt-6 text-xl font-semibold text-gray-900">
              Crédit d'impôt
            </h3>
            <p className="mt-4 text-gray-600">
              Crédit d'impôt pour la formation de la main-d'œuvre dans les secteurs 
              manufacturier et technologique. Profitez d'avantages fiscaux.
            </p>
            <button className="mt-6 text-blue-600 font-medium hover:text-blue-700">
              En savoir plus →
            </button>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8">
            <Building2 className="h-12 w-12 text-blue-600" />
            <h3 className="mt-6 text-xl font-semibold text-gray-900">
              Loi sur les compétences
            </h3>
            <p className="mt-4 text-gray-600">
              1% de la masse salariale doit être investi dans la formation. Optimisez 
              vos investissements avec nos formations certifiées.
            </p>
            <button className="mt-6 text-blue-600 font-medium hover:text-blue-700">
              En savoir plus →
            </button>
          </div>
        </div>

        <div className="mt-16 bg-blue-600 rounded-2xl p-8 text-white">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <FileText className="h-12 w-12 mx-auto mb-4" />
              <h4 className="text-lg font-semibold">Documentation Simplifiée</h4>
              <p className="mt-2 text-blue-100">
                Nous vous accompagnons dans toutes vos démarches administratives
              </p>
            </div>
            <div className="text-center">
              <Briefcase className="h-12 w-12 mx-auto mb-4" />
              <h4 className="text-lg font-semibold">Formations Éligibles</h4>
              <p className="mt-2 text-blue-100">
                Toutes nos formations sont éligibles aux aides gouvernementales
              </p>
            </div>
            <div className="text-center">
              <GraduationCap className="h-12 w-12 mx-auto mb-4" />
              <h4 className="text-lg font-semibold">Certification Reconnue</h4>
              <p className="mt-2 text-blue-100">
                Obtenez une certification reconnue par l'industrie
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GovPrograms;