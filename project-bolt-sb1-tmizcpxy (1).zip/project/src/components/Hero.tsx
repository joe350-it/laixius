import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, Navigation, Pagination } from 'swiper/modules';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

const Hero = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const slides = [
    {
      image: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80",
      alt: "Intelligence Artificielle en entreprise",
      title: "Transformez votre entreprise avec l'IA",
      subtitle: "Lexius vous accompagne dans l'intégration de solutions d'IA innovantes et sur mesure"
    },
    {
      image: "https://images.unsplash.com/photo-1531545514256-b1400bc00f31?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80",
      alt: "Consultation en IA",
      title: "Expertise en Intelligence Artificielle",
      subtitle: "Des solutions adaptées à vos besoins spécifiques pour optimiser votre performance"
    },
    {
      image: "https://images.unsplash.com/photo-1552664688-cf412ec27db2?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80",
      alt: "Innovation IA",
      title: "L'Innovation au Service de Votre Croissance",
      subtitle: "Découvrez comment l'IA peut révolutionner votre secteur d'activité"
    }
  ];

  return (
    <div className="relative bg-gradient-to-b from-primary-950 to-primary-900 pt-16">
      <div 
        className="absolute inset-0 bg-gradient-radial from-secondary-500/20 via-transparent to-transparent"
        style={{
          background: 'radial-gradient(circle at 50% 50%, rgba(217, 70, 239, 0.15), transparent 60%)',
        }}
      />
      
      <div className="absolute inset-0">
        <Swiper
          modules={[Autoplay, Navigation, Pagination]}
          spaceBetween={0}
          slidesPerView={1}
          navigation
          pagination={{ clickable: true }}
          autoplay={{ delay: 5000 }}
          loop={true}
          className="w-full h-full"
        >
          {slides.map((slide, index) => (
            <SwiperSlide key={index}>
              <div className="relative w-full h-[90vh] overflow-hidden">
                <motion.img
                  initial={{ scale: 1.1, opacity: 0.5 }}
                  animate={{ scale: 1, opacity: 0.2 }}
                  transition={{ duration: 10 }}
                  className="w-full h-full object-cover"
                  src={slide.image}
                  alt={slide.alt}
                />
                <div className="absolute inset-0 bg-black/80" />
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="absolute inset-0 flex flex-col justify-center items-center text-center px-4 max-w-6xl mx-auto"
                >
                  <div className="relative">
                    <motion.div
                      className="absolute -inset-1 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-30"
                      animate={{
                        opacity: [0.3, 0.5, 0.3],
                        scale: [1, 1.05, 1],
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        repeatType: "reverse",
                      }}
                    />
                    <h2 className="relative text-4xl md:text-6xl font-bold text-white mb-6 leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-primary-200">
                      {slide.title}
                    </h2>
                  </div>
                  <p className="text-xl md:text-2xl text-primary-100/90 max-w-3xl">
                    {slide.subtitle}
                  </p>
                </motion.div>
              </div>
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
      
      <motion.div 
        ref={ref}
        initial={{ opacity: 0, y: 20 }}
        animate={inView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8 mt-[60vh]"
      >
        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-gradient-to-r from-secondary-500 to-primary-500 text-white rounded-full font-medium text-lg hover:opacity-90 transition-all duration-300 shadow-lg shadow-secondary-500/25"
          >
            Découvrir nos services
          </motion.button>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 border-2 border-primary-200/30 text-white rounded-full font-medium text-lg hover:bg-white/5 transition-all duration-300"
          >
            Consultation gratuite
          </motion.button>
        </div>
      </motion.div>

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-secondary-500/10 rounded-full filter blur-3xl animate-float" />
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-primary-500/10 rounded-full filter blur-3xl animate-float" style={{ animationDelay: '-2s' }} />
        <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-primary-400/10 rounded-full filter blur-3xl animate-float" style={{ animationDelay: '-4s' }} />
      </div>
    </div>
  );
};

export default Hero;