import React from 'react';
import { GraduationCap, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center">
              <GraduationCap className="h-8 w-8 text-blue-400" />
              <span className="ml-2 text-xl font-bold text-white">TechFormation Montréal</span>
            </div>
            <p className="mt-4 text-gray-300">
              Formation professionnelle en TI de haute qualité à Montréal. 
              Experts certifiés avec plus de 16 ans d'expérience.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center text-gray-300">
                <Mail className="h-5 w-5 mr-2" />
                <a href="mailto:contact@techformation.ca">contact@techformation.ca</a>
              </li>
              <li className="flex items-center text-gray-300">
                <Phone className="h-5 w-5 mr-2" />
                <a href="tel:+15140000000">+1 (514) 000-0000</a>
              </li>
              <li className="flex items-center text-gray-300">
                <MapPin className="h-5 w-5 mr-2" />
                <span>Montréal, QC, Canada</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Navigation</h3>
            <ul className="space-y-3">
              <li><a href="#services" className="text-gray-300 hover:text-blue-400">Services</a></li>
              <li><a href="#trainers" className="text-gray-300 hover:text-blue-400">Formateurs</a></li>
              <li><a href="#calendar" className="text-gray-300 hover:text-blue-400">Calendrier</a></li>
              <li><a href="#programs" className="text-gray-300 hover:text-blue-400">Programmes</a></li>
            </ul>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t border-gray-700">
          <p className="text-center text-gray-400">
            © {new Date().getFullYear()} TechFormation Montréal. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;