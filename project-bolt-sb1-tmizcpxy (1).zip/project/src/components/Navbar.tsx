import React, { useState, useEffect } from 'react';
import { Menu, X, Brain, LogIn } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const menuItems = [
    { name: 'Accueil', path: '/' },
    { name: 'À propos', path: '/about' },
    { name: 'Consultation', path: '/consultation' },
    { name: 'Formation', path: '/formation' },
    { name: 'Notre équipe', path: '/trainers' }
  ];

  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-primary-950/90 backdrop-blur-md shadow-lg' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <motion.div 
            className="flex-1 flex items-center justify-start"
            whileHover={{ scale: 1.05 }}
          >
            <Link to="/" className="flex items-center">
              <Brain className="h-8 w-8 text-secondary-500" />
              <span className="ml-2 text-xl font-bold text-white">
                Lexius
              </span>
            </Link>
          </motion.div>
          
          <div className="hidden md:flex flex-1 items-center justify-center">
            <div className="flex space-x-4 whitespace-nowrap">
              {menuItems.map((item, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.1 }}
                  className="relative group"
                >
                  <Link
                    to={item.path}
                    className="text-primary-100 hover:text-white px-3 py-2 text-sm font-medium transition-colors"
                  >
                    {item.name}
                  </Link>
                  <motion.div
                    className="absolute bottom-0 left-0 w-full h-0.5 bg-secondary-500 scale-x-0 group-hover:scale-x-100 transition-transform origin-left"
                    initial={false}
                  />
                </motion.div>
              ))}
            </div>
          </div>

          <div className="hidden md:flex flex-1 items-center justify-end space-x-4">
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-2 bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-full text-sm font-medium transition-all duration-300 hover:opacity-90 shadow-lg shadow-primary-500/25"
            >
              <Link to="/calendar">Calendrier</Link>
            </motion.button>

            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-2 bg-gradient-to-r from-secondary-500 to-primary-500 text-white rounded-full text-sm font-medium transition-all duration-300 hover:opacity-90 shadow-lg shadow-secondary-500/25"
            >
              <Link to="/contact">Contactez-nous</Link>
            </motion.button>

            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center px-4 py-2 text-primary-100 hover:text-white"
            >
              <Link to="/login" className="flex items-center">
                <LogIn className="h-4 w-4 mr-2" />
                <span>Connexion formation</span>
              </Link>
            </motion.button>
          </div>

          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)}>
              {isOpen ? (
                <X className="h-6 w-6 text-white" />
              ) : (
                <Menu className="h-6 w-6 text-white" />
              )}
            </button>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-primary-950/95 backdrop-blur-md"
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {menuItems.map((item, index) => (
                <Link
                  key={index}
                  to={item.path}
                  className="block px-3 py-2 text-primary-100 hover:text-white"
                  onClick={() => setIsOpen(false)}
                >
                  {item.name}
                </Link>
              ))}
              <Link
                to="/calendar"
                className="block px-3 py-2 text-primary-100 hover:text-white"
                onClick={() => setIsOpen(false)}
              >
                Calendrier
              </Link>
              <Link
                to="/contact"
                className="block px-3 py-2 text-primary-100 hover:text-white"
                onClick={() => setIsOpen(false)}
              >
                Contactez-nous
              </Link>
              <Link
                to="/login"
                className="block px-3 py-2 text-primary-100 hover:text-white"
                onClick={() => setIsOpen(false)}
              >
                Connexion formation
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
};

export default Navbar;