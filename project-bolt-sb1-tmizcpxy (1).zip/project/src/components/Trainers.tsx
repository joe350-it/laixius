import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Mail, Award, BookOpen } from 'lucide-react';

const trainers = [
  {
    name: 'Dr. Sophie Dubois',
    role: 'Directrice de la Formation & Experte en IA',
    image: 'https://this-person-does-not-exist.com/img/avatar-gen11a4f3cde3fcf0c674c8bd6d.jpg',
    description: 'Docteure en Intelligence Artificielle avec plus de 12 ans d\'expérience. Spécialisée dans l\'IA appliquée et l\'apprentissage automatique.',
    expertise: ['Deep Learning', 'NLP', 'Computer Vision', 'IA Éthique'],
    certifications: ['PhD en IA', 'Google Cloud AI', 'IBM AI Engineering'],
    projects: '200+ projets IA réalisés'
  },
  {
    name: 'Marc-Antoine Lefebvre',
    role: 'Expert Senior en IA Générative',
    image: 'https://this-person-does-not-exist.com/img/avatar-gen1144829de3fcf0c674c8bd6d.jpg',
    description: '15 ans d\'expérience en développement d\'IA. Expert en IA générative et en systèmes conversationnels avancés.',
    expertise: ['IA Générative', 'ChatGPT', 'Stable Diffusion', 'LLMs'],
    certifications: ['Microsoft AI Engineer', 'OpenAI API Expert'],
    projects: '150+ solutions déployées'
  },
  {
    name: 'Dr. Alexandre Chen',
    role: 'Responsable Innovation IA',
    image: 'https://this-person-does-not-exist.com/img/avatar-gen1147829de3fcf0c674c8bd6d.jpg',
    description: 'Docteur en Machine Learning avec une expertise particulière dans l\'IA pour l\'industrie 4.0 et l\'automatisation intelligente.',
    expertise: ['Machine Learning', 'AutoML', 'IoT & IA', 'Edge Computing'],
    certifications: ['PhD ML', 'AWS Machine Learning', 'NVIDIA DLI'],
    projects: '180+ implémentations'
  },
  {
    name: 'Jonathan Desjardins',
    role: 'Co-fondateur & Formateur Senior',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    description: 'Plus de 16 ans d\'expérience en TI et en enseignement des technologies. Expert en développement et architecture logicielle.',
    expertise: ['Intelligence Artificielle', 'Deep Learning', 'Architecture Cloud', 'DevOps'],
    certifications: ['AWS Certified Solutions Architect', 'Google Cloud Professional AI Engineer'],
    projects: '150+ projets IA réalisés'
  },
  {
    name: 'Adil Haouzia',
    role: 'Co-fondateur & Formateur Senior',
    image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&q=80',
    description: 'Plus de 16 ans d\'expérience en TI et en formation. Spécialiste en infrastructure cloud et cybersécurité.',
    expertise: ['Machine Learning', 'Big Data', 'Cybersécurité', 'Cloud Computing'],
    certifications: ['Microsoft Certified: Azure AI Engineer', 'IBM AI Engineering Professional'],
    projects: '120+ entreprises accompagnées'
  }
];

const Trainers = () => {
  return (
    <section id="trainers" className="py-20 bg-primary-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400 sm:text-4xl">
              Notre Équipe d'Experts
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-primary-200">
              Une équipe de professionnels passionnés par l'IA et l'innovation
            </p>
          </motion.div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-12 lg:grid-cols-3">
          {trainers.map((trainer, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="relative group"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300" />
              <div className="relative bg-primary-900 p-8 rounded-lg">
                <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-6">
                  <div className="relative">
                    <div className="w-40 h-40 rounded-full overflow-hidden ring-4 ring-secondary-500/30">
                      <img
                        className="w-full h-full object-cover"
                        src={trainer.image}
                        alt={trainer.name}
                      />
                    </div>
                    <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-2 bg-primary-800 rounded-full text-primary-200 hover:text-secondary-400 transition-colors"
                      >
                        <Linkedin className="w-5 h-5" />
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-2 bg-primary-800 rounded-full text-primary-200 hover:text-secondary-400 transition-colors"
                      >
                        <Mail className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </div>
                  
                  <div className="flex-1 text-center md:text-left">
                    <h3 className="text-2xl font-semibold text-white">{trainer.name}</h3>
                    <p className="text-secondary-400 font-medium">{trainer.role}</p>
                    <p className="mt-4 text-primary-200">{trainer.description}</p>
                    
                    <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center space-x-2">
                        <Award className="w-5 h-5 text-secondary-400" />
                        <span className="text-primary-200">{trainer.projects}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <BookOpen className="w-5 h-5 text-secondary-400" />
                        <span className="text-primary-200">{trainer.certifications.length} certifications</span>
                      </div>
                    </div>

                    <div className="mt-6">
                      <h4 className="text-sm font-semibold text-primary-200 uppercase tracking-wider mb-2">
                        Expertise
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {trainer.expertise.map((skill, i) => (
                          <span
                            key={i}
                            className="px-3 py-1 bg-primary-800 text-primary-200 rounded-full text-sm"
                          >
                            {skill}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Trainers;