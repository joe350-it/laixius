import React from 'react';
import { motion } from 'framer-motion';

const VideoSection = () => {
  return (
    <section className="py-20 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-3xl font-extrabold text-white sm:text-4xl"
          >
            L'IA au Service de Votre Entreprise
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-4 max-w-2xl mx-auto text-xl text-gray-300"
          >
            Découvrez comment l'intelligence artificielle peut transformer votre entreprise
          </motion.p>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-12 relative aspect-video rounded-2xl overflow-hidden bg-black shadow-2xl"
        >
          <video
            className="w-full h-full object-cover"
            autoPlay
            loop
            muted
            playsInline
            controls={false}
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-digital-animation-of-a-network-of-neurons-in-the-human-49438-large.mp4" type="video/mp4" />
            Your browser does not support the video tag.
          </video>
          <div className="absolute inset-0 bg-black/20 pointer-events-none" />
        </motion.div>

        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="bg-primary-900/50 p-6 rounded-lg backdrop-blur-sm"
          >
            <h3 className="text-lg font-semibold text-white">Transformation Digitale</h3>
            <p className="mt-2 text-gray-300">
              Découvrez comment l'IA peut accélérer votre transformation digitale
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="bg-primary-900/50 p-6 rounded-lg backdrop-blur-sm"
          >
            <h3 className="text-lg font-semibold text-white">Productivité Améliorée</h3>
            <p className="mt-2 text-gray-300">
              Automatisez les tâches répétitives et focalisez-vous sur l'essentiel
            </p>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1 }}
            className="bg-primary-900/50 p-6 rounded-lg backdrop-blur-sm"
          >
            <h3 className="text-lg font-semibold text-white">Innovation Continue</h3>
            <p className="mt-2 text-gray-300">
              Restez à la pointe avec les dernières avancées en IA
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;