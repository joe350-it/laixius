import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { type: 'bot', content: 'Bonjour! Comment puis-je vous aider aujourd\'hui?' }
  ]);
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    setMessages([...messages, { type: 'user', content: input }]);
    // Simuler une réponse du bot
    setTimeout(() => {
      setMessages(prev => [...prev, { 
        type: 'bot', 
        content: "Je suis là pour répondre à vos questions sur nos formations en IA. N'hésitez pas à me poser vos questions!" 
      }]);
    }, 1000);
    setInput('');
  };

  return (
    <>
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-4 right-4 p-4 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-full text-white shadow-lg z-50"
      >
        <MessageSquare className="h-6 w-6" />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            className="fixed bottom-20 right-4 w-96 bg-primary-900 rounded-lg shadow-xl z-50"
          >
            <div className="p-4 border-b border-primary-700 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-white">Assistant IA</h3>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-primary-200 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="h-96 overflow-y-auto p-4 space-y-4">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-secondary-500 text-white'
                        : 'bg-primary-800 text-primary-100'
                    }`}
                  >
                    {message.content}
                  </div>
                </div>
              ))}
            </div>

            <form onSubmit={handleSubmit} className="p-4 border-t border-primary-700">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="Écrivez votre message..."
                  className="flex-1 p-2 rounded-lg bg-primary-800 text-white placeholder-primary-400 border border-primary-700 focus:outline-none focus:border-secondary-500"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg text-white hover:opacity-90"
                >
                  Envoyer
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Chatbot;