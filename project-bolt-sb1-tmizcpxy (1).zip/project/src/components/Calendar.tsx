import React from 'react';
import { Calendar as CalendarIcon, Clock, Users as UsersIcon } from 'lucide-react';

const TrainingCalendar = () => {
  const formations = [
    {
      title: 'Introduction à l\'IA Générative',
      date: '15 avril 2024',
      duration: '2 jours',
      type: 'Présentiel',
      level: 'Débutant',
      price: '995 CAD'
    },
    {
      title: 'ChatGPT & DALL-E pour Entreprises',
      date: '22 avril 2024',
      duration: '1 jour',
      type: 'Hybride',
      level: 'Intermédiaire',
      price: '595 CAD'
    },
    {
      title: 'IA pour l\'Automatisation',
      date: '6 mai 2024',
      duration: '3 jours',
      type: 'Présentiel',
      level: 'Avancé',
      price: '1495 CAD'
    }
  ];

  return (
    <section id="calendar" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Calendrier des Formations
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Inscrivez-vous à nos prochaines sessions de formation en IA
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
          {formations.map((formation, index) => (
            <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  {formation.title}
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center text-gray-600">
                    <CalendarIcon className="h-5 w-5 mr-2" />
                    <span>{formation.date}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Clock className="h-5 w-5 mr-2" />
                    <span>{formation.duration}</span>
                  </div>
                  <div className="flex items-center text-gray-600">
                    <UsersIcon className="h-5 w-5 mr-2" />
                    <span>{formation.type} - {formation.level}</span>
                  </div>
                </div>
                <div className="mt-6">
                  <div className="text-2xl font-bold text-blue-600 mb-4">
                    {formation.price}
                  </div>
                  <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors">
                    S'inscrire
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="inline-flex items-center px-6 py-3 border border-blue-600 text-base font-medium rounded-md text-blue-600 hover:bg-blue-50">
            Voir toutes les dates
          </button>
        </div>
      </div>
    </section>
  );
};

export default TrainingCalendar;