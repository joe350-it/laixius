import React from 'react';
import { Building2 } from 'lucide-react';

const partners = [
  {
    name: 'TechnoQuébec',
    description: 'Leader en solutions technologiques',
    logo: <Building2 className="h-16 w-16 text-blue-600" />
  },
  {
    name: 'IA Montréal',
    description: 'Consortium en intelligence artificielle',
    logo: <Building2 className="h-16 w-16 text-blue-600" />
  },
  {
    name: 'Digital Solutions Inc.',
    description: 'Experts en transformation numérique',
    logo: <Building2 className="h-16 w-16 text-blue-600" />
  },
  {
    name: 'Innovation Lab QC',
    description: 'Centre de recherche en IA',
    logo: <Building2 className="h-16 w-16 text-blue-600" />
  }
];

const Partners = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Nos Partenaires
          </h2>
          <p className="mt-4 max-w-2xl mx-auto text-xl text-gray-500">
            Ils nous font confiance pour former leurs équipes
          </p>
        </div>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {partners.map((partner, index) => (
            <div key={index} className="bg-white p-8 rounded-lg shadow-lg text-center">
              <div className="flex justify-center">{partner.logo}</div>
              <h3 className="mt-4 text-xl font-semibold text-gray-900">{partner.name}</h3>
              <p className="mt-2 text-gray-500">{partner.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Partners;