import React from 'react';
import { Brain, Cpu, GitBranch, Database, Target, Users } from 'lucide-react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';

const services = [
  {
    icon: <Brain className="h-8 w-8" />,
    title: 'Fondamentaux de l\'IA',
    description: 'Maîtrisez les concepts clés de l\'IA, du machine learning et du deep learning.',
    gradient: 'from-blue-500 to-purple-500'
  },
  {
    icon: <Cpu className="h-8 w-8" />,
    title: 'IA Générative',
    description: 'Créez du contenu avec GPT, DALL-E et autres modèles d\'IA générative.',
    gradient: 'from-purple-500 to-pink-500'
  },
  {
    icon: <GitBranch className="h-8 w-8" />,
    title: 'Automatisation',
    description: 'Optimisez vos processus métiers avec l\'IA et le RPA.',
    gradient: 'from-pink-500 to-red-500'
  },
  {
    icon: <Database className="h-8 w-8" />,
    title: 'Analyse de Données',
    description: 'Exploitez le Big Data et l\'analytics pour des décisions éclairées.',
    gradient: 'from-red-500 to-orange-500'
  },
  {
    icon: <Target className="h-8 w-8" />,
    title: 'IA Métiers',
    description: 'Solutions IA spécifiques pour marketing, finance, RH et industrie.',
    gradient: 'from-orange-500 to-yellow-500'
  },
  {
    icon: <Users className="h-8 w-8" />,
    title: 'Formation Sur Mesure',
    description: 'Programmes personnalisés adaptés aux besoins de votre entreprise.',
    gradient: 'from-yellow-500 to-green-500'
  }
];

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { 
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section id="services" className="py-20 bg-primary-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-extrabold text-white sm:text-4xl bg-clip-text text-transparent bg-gradient-to-r from-secondary-400 to-primary-400">
              Nos Formations en Intelligence Artificielle
            </h2>
            <p className="mt-4 max-w-2xl mx-auto text-xl text-primary-200">
              Des formations pratiques et innovantes pour maîtriser l'IA
            </p>
          </motion.div>
        </div>

        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="mt-20 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3"
        >
          {services.map((service, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="relative group"
            >
              <div className="absolute -inset-0.5 bg-gradient-to-r opacity-75 group-hover:opacity-100 transition-opacity duration-300 rounded-lg blur"
                style={{
                  backgroundImage: `linear-gradient(to right, var(--tw-gradient-stops))`,
                  '--tw-gradient-from': '#d946ef',
                  '--tw-gradient-to': '#0ea5e9',
                }}
              />
              <div className="relative bg-primary-900 p-8 rounded-lg transform transition-all duration-300 group-hover:-translate-y-1">
                <div className={`inline-flex p-3 rounded-lg bg-gradient-to-r ${service.gradient} bg-opacity-10`}>
                  <div className="text-white">{service.icon}</div>
                </div>
                <h3 className="mt-4 text-lg font-medium text-white group-hover:text-secondary-400 transition-colors">
                  {service.title}
                </h3>
                <p className="mt-2 text-base text-primary-300">
                  {service.description}
                </p>
                <div className="mt-4 flex items-center text-secondary-400 group-hover:text-secondary-300">
                  <span className="text-sm font-medium">En savoir plus</span>
                  <svg className="ml-2 w-4 h-4 transform group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Services;