import React from 'react';
import { Target, Users, Lightbulb, Trophy, Brain, Cpu, BookOpen, Award } from 'lucide-react';
import { motion } from 'framer-motion';

const About = () => {
  return (
    <div className="min-h-screen bg-primary-950">
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-b from-primary-900 to-primary-950">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-secondary-500/20 via-transparent to-primary-500/20 opacity-30" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400 sm:text-5xl lg:text-6xl">
                Notre Histoire, Notre Mission
              </h1>
              <p className="mt-6 max-w-3xl mx-auto text-xl text-primary-200">
                Découvrez comment InnovAI Academy transforme l'apprentissage de l'IA au Québec
              </p>
            </motion.div>
          </div>
        </section>

        {/* Mission et Vision */}
        <section className="py-20 bg-primary-900/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400 mb-6">
                  Notre Mission
                </h2>
                <p className="text-lg text-primary-200">
                  Chez InnovAI Academy, notre mission est de démocratiser l'intelligence artificielle 
                  en offrant des formations pratiques, interactives et adaptées aux besoins des 
                  entreprises québécoises. Nous croyons que l'IA doit être accessible à tous et que 
                  son apprentissage peut être à la fois enrichissant et agréable.
                </p>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="relative group"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300" />
                <div className="relative">
                  <img
                    src="https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
                    alt="Équipe en formation"
                    className="rounded-lg shadow-xl"
                  />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Nos Valeurs */}
        <section className="py-20 bg-primary-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400 mb-12"
            >
              Nos Valeurs
            </motion.h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: <Target className="h-12 w-12" />,
                  title: "Excellence",
                  description: "Nous visons l'excellence dans chaque formation"
                },
                {
                  icon: <Users className="h-12 w-12" />,
                  title: "Collaboration",
                  description: "L'apprentissage est une expérience collective"
                },
                {
                  icon: <Lightbulb className="h-12 w-12" />,
                  title: "Innovation",
                  description: "Toujours à la pointe de la technologie"
                },
                {
                  icon: <Trophy className="h-12 w-12" />,
                  title: "Réussite",
                  description: "Votre succès est notre priorité"
                }
              ].map((value, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-50 group-hover:opacity-75 transition duration-300" />
                  <div className="relative bg-primary-900 p-6 rounded-lg text-center">
                    <div className="text-secondary-400 group-hover:text-secondary-300 transition-colors">
                      {value.icon}
                    </div>
                    <h3 className="text-xl font-semibold text-white mt-4 mb-2">{value.title}</h3>
                    <p className="text-primary-200">{value.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-20 bg-primary-900/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center mb-12"
            >
              <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400">
                Questions Fréquentes
              </h2>
              <p className="mt-4 text-xl text-primary-200">
                Tout ce que vous devez savoir sur l'IA et nos formations
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                {
                  question: "Qu'est-ce que l'IA peut apporter à mon entreprise ?",
                  answer: "L'IA peut automatiser les tâches répétitives, améliorer la prise de décision, optimiser les processus et créer de nouvelles opportunités d'innovation."
                },
                {
                  question: "Combien coûte l'implémentation de l'IA ?",
                  answer: "Les coûts varient selon vos besoins. Nous proposons des solutions adaptées à tous les budgets, à partir de 5000$ pour des projets pilotes."
                },
                {
                  question: "Combien de temps dure une formation ?",
                  answer: "Nos formations varient de 1 à 5 jours selon le niveau et le sujet. Nous proposons aussi des parcours personnalisés."
                },
                {
                  question: "Faut-il des connaissances préalables ?",
                  answer: "Non, nos formations sont adaptées à tous les niveaux, du débutant à l'expert. Nous vous accompagnons pas à pas."
                }
              ].map((faq, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-50 group-hover:opacity-75 transition duration-300" />
                  <div className="relative bg-primary-900 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-white mb-3">{faq.question}</h3>
                    <p className="text-primary-200">{faq.answer}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default About;