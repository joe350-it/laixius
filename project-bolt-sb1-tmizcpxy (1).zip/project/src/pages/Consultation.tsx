import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Bot, LineChart, Cpu, Users, Lightbulb, Mail, Phone, MapPin } from 'lucide-react';
import Footer from '../components/Footer';

const consultationServices = [
  {
    icon: <Brain className="h-12 w-12" />,
    title: 'Stratégie IA',
    description: 'Développement de stratégies d\'IA personnalisées pour votre entreprise, identification des opportunités et planification de l\'implémentation.',
    features: [
      'Audit de maturité IA',
      'Feuille de route stratégique',
      'Analyse des cas d\'usage',
      'Évaluation ROI'
    ]
  },
  {
    icon: <Bot className="h-12 w-12" />,
    title: 'Automatisation des Processus',
    description: 'Optimisation de vos processus métiers grâce à l\'IA et l\'automatisation intelligente.',
    features: [
      'Analyse des processus',
      'Développement de solutions IA',
      'Intégration RPA',
      'Formation des équipes'
    ]
  },
  {
    icon: <LineChart className="h-12 w-12" />,
    title: 'Analytics Avancé',
    description: 'Exploitation de vos données pour des insights actionnables et une prise de décision optimisée.',
    features: [
      'Data Mining',
      'Modélisation prédictive',
      'Visualisation des données',
      'Recommandations stratégiques'
    ]
  }
];

const Consultation = () => {
  return (
    <div className="min-h-screen bg-primary-950">
      <div className="pt-24">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-primary-950 to-primary-900 opacity-90" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400">
                Services de Consultation en IA
              </h1>
              <p className="mt-6 max-w-3xl mx-auto text-xl text-primary-200">
                Transformez votre entreprise avec nos solutions d'IA sur mesure
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="mt-8 px-8 py-4 bg-gradient-to-r from-secondary-500 to-primary-500 text-white rounded-full text-lg font-medium hover:opacity-90 transition-all duration-300 shadow-lg shadow-secondary-500/25"
              >
                Planifier une consultation
              </motion.button>
            </motion.div>
          </div>
        </section>

        {/* Services Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {consultationServices.map((service, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300" />
                  <div className="relative bg-primary-900 p-8 rounded-lg">
                    <div className="text-secondary-400 group-hover:text-secondary-300 transition-colors">
                      {service.icon}
                    </div>
                    <h3 className="mt-4 text-xl font-semibold text-white">
                      {service.title}
                    </h3>
                    <p className="mt-2 text-primary-300">
                      {service.description}
                    </p>
                    <ul className="mt-4 space-y-2">
                      {service.features.map((feature, i) => (
                        <li key={i} className="flex items-center text-primary-200">
                          <span className="h-1.5 w-1.5 bg-secondary-400 rounded-full mr-2" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Process Section */}
        <section className="py-20 bg-primary-900/50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white">
                Notre Approche
              </h2>
              <p className="mt-4 text-xl text-primary-200">
                Une méthodologie éprouvée pour votre transformation digitale
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {[
                {
                  icon: <Users className="h-8 w-8" />,
                  title: 'Découverte',
                  description: 'Analyse de vos besoins et objectifs'
                },
                {
                  icon: <Lightbulb className="h-8 w-8" />,
                  title: 'Stratégie',
                  description: 'Élaboration d\'une solution personnalisée'
                },
                {
                  icon: <Cpu className="h-8 w-8" />,
                  title: 'Implémentation',
                  description: 'Mise en place des solutions IA'
                },
                {
                  icon: <LineChart className="h-8 w-8" />,
                  title: 'Optimisation',
                  description: 'Suivi et amélioration continue'
                }
              ].map((step, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="inline-flex p-3 rounded-lg bg-secondary-500/10 text-secondary-400">
                    {step.icon}
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-white">
                    {step.title}
                  </h3>
                  <p className="mt-2 text-primary-300">
                    {step.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="relative"
              >
                <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-75" />
                <div className="relative bg-primary-900 p-8 rounded-lg">
                  <h3 className="text-2xl font-bold text-white mb-6">
                    Contactez-nous
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4 text-primary-200">
                      <Mail className="h-6 w-6 text-secondary-400" />
                      <span>contact@innovai.ca</span>
                    </div>
                    <div className="flex items-center space-x-4 text-primary-200">
                      <Phone className="h-6 w-6 text-secondary-400" />
                      <span>+1 (514) 000-0000</span>
                    </div>
                    <div className="flex items-center space-x-4 text-primary-200">
                      <MapPin className="h-6 w-6 text-secondary-400" />
                      <span>Montréal, QC, Canada</span>
                    </div>
                  </div>
                </div>
              </motion.div>

              <motion.form
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="space-y-6"
              >
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-primary-200">
                    Nom complet
                  </label>
                  <input
                    type="text"
                    id="name"
                    className="mt-1 block w-full rounded-md bg-primary-900 border-primary-700 text-primary-200 focus:border-secondary-500 focus:ring focus:ring-secondary-500 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-primary-200">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    className="mt-1 block w-full rounded-md bg-primary-900 border-primary-700 text-primary-200 focus:border-secondary-500 focus:ring focus:ring-secondary-500 focus:ring-opacity-50"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-primary-200">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={4}
                    className="mt-1 block w-full rounded-md bg-primary-900 border-primary-700 text-primary-200 focus:border-secondary-500 focus:ring focus:ring-secondary-500 focus:ring-opacity-50"
                  />
                </div>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  type="submit"
                  className="w-full px-6 py-3 bg-gradient-to-r from-secondary-500 to-primary-500 text-white rounded-full font-medium hover:opacity-90 transition-all duration-300 shadow-lg shadow-secondary-500/25"
                >
                  Envoyer
                </motion.button>
              </motion.form>
            </div>
          </div>
        </section>
      </div>
      <Footer />
    </div>
  );
};

export default Consultation;