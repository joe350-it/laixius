import React from 'react';
import { motion } from 'framer-motion';
import { Book, Clock, Award, Star, Video, FileText, MessageSquare, Code, Brain, Cpu } from 'lucide-react';

const courses = [
  {
    id: 1,
    title: "Maîtriser ChatGPT en Entreprise",
    description: "Apprenez à utiliser efficacement ChatGPT pour améliorer votre productivité et vos processus d'entreprise",
    duration: "8 heures",
    level: "Tous niveaux",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Introduction à ChatGPT",
      "Prompts efficaces",
      "Cas d'usage en entreprise",
      "Bonnes pratiques et limites"
    ],
    free: true,
    instructor: "Marc-Antoine Lefebvre"
  },
  {
    id: 2,
    title: "Claude : IA Avancée pour Professionnels",
    description: "Découvrez les capacités avancées de Claude pour l'analyse et la génération de contenu",
    duration: "10 heures",
    level: "Intermédiaire",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1676377923141-0a955e5c5fc4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Présentation de Claude",
      "Analyse de documents",
      "Génération de code",
      "Études de cas"
    ],
    free: true,
    instructor: "Dr. Sophie Dubois"
  },
  {
    id: 3,
    title: "GitHub Copilot pour Développeurs",
    description: "Optimisez votre développement avec l'assistant IA GitHub Copilot",
    duration: "12 heures",
    level: "Avancé",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1678995632928-1f153bcb6d12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Configuration de Copilot",
      "Génération de code",
      "Tests automatisés",
      "Meilleures pratiques"
    ],
    free: true,
    instructor: "Dr. Alexandre Chen"
  },
  {
    id: 4,
    title: "Introduction à l'IA : Fondamentaux",
    description: "Comprendre les bases de l'IA et son impact sur le monde professionnel",
    duration: "15 heures",
    level: "Débutant",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Qu'est-ce que l'IA ?",
      "Types d'IA",
      "Outils populaires",
      "Applications pratiques"
    ],
    free: true,
    instructor: "Dr. Sophie Dubois"
  },
  {
    id: 5,
    title: "IA pour l'Analyse de Données",
    description: "Utilisez l'IA pour extraire des insights de vos données",
    duration: "20 heures",
    level: "Intermédiaire",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1676377923141-0a955e5c5fc4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Préparation des données",
      "Analyse prédictive",
      "Visualisation",
      "Rapports automatisés"
    ],
    free: true,
    instructor: "Dr. Alexandre Chen"
  },
  {
    id: 6,
    title: "IA pour le Marketing Digital",
    description: "Optimisez vos campagnes marketing avec l'IA",
    duration: "15 heures",
    level: "Intermédiaire",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1678995632928-1f153bcb6d12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "SEO intelligent",
      "Personnalisation",
      "Automation marketing",
      "Analytics avancé"
    ],
    free: true,
    instructor: "Marc-Antoine Lefebvre"
  },
  {
    id: 7,
    title: "IA pour l'Automatisation RPA",
    description: "Automatisez vos processus métier avec l'IA",
    duration: "18 heures",
    level: "Avancé",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Fondamentaux RPA",
      "Intégration IA",
      "Workflows intelligents",
      "Cas pratiques"
    ],
    free: true,
    instructor: "Dr. Alexandre Chen"
  },
  {
    id: 8,
    title: "IA pour la Relation Client",
    description: "Améliorez votre service client avec l'IA",
    duration: "12 heures",
    level: "Intermédiaire",
    rating: 4.8,
    image: "https://images.unsplash.com/photo-1676377923141-0a955e5c5fc4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Chatbots intelligents",
      "Analyse des sentiments",
      "Personnalisation",
      "Support prédictif"
    ],
    free: true,
    instructor: "Dr. Sophie Dubois"
  },
  {
    id: 9,
    title: "IA pour la Cybersécurité",
    description: "Protégez votre entreprise avec l'IA",
    duration: "20 heures",
    level: "Avancé",
    rating: 4.9,
    image: "https://images.unsplash.com/photo-1678995632928-1f153bcb6d12?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Détection des menaces",
      "Prévention",
      "Réponse aux incidents",
      "Conformité"
    ],
    free: true,
    instructor: "Dr. Alexandre Chen"
  },
  {
    id: 10,
    title: "IA pour la Gestion de Projet",
    description: "Optimisez la gestion de projet avec l'IA",
    duration: "15 heures",
    level: "Intermédiaire",
    rating: 4.7,
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    modules: [
      "Planification intelligente",
      "Estimation des risques",
      "Allocation des ressources",
      "Suivi automatisé"
    ],
    free: true,
    instructor: "Marc-Antoine Lefebvre"
  }
];

const Formation = () => {
  return (
    <div className="min-h-screen bg-primary-950">
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative py-20 bg-gradient-to-b from-primary-900 to-primary-950">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-secondary-500/20 via-transparent to-primary-500/20 opacity-30" />
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center"
            >
              <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-secondary-400 to-primary-400 sm:text-5xl lg:text-6xl">
                Formations en IA chez Lexius
              </h1>
              <p className="mt-6 max-w-3xl mx-auto text-xl text-primary-200">
                Des formations pratiques et interactives pour maîtriser l'IA
              </p>
            </motion.div>
          </div>
        </section>

        {/* Courses Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {courses.map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="relative group"
                >
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-secondary-500 to-primary-500 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-300" />
                  <div className="relative bg-primary-900 rounded-lg overflow-hidden">
                    <div className="h-48 relative">
                      <img
                        src={course.image}
                        alt={course.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-primary-900 to-transparent" />
                      {course.free && (
                        <div className="absolute top-4 right-4 px-3 py-1 bg-secondary-500 text-white rounded-full text-sm font-medium">
                          Gratuit
                        </div>
                      )}
                    </div>
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <span className="px-3 py-1 bg-secondary-500/10 text-secondary-400 rounded-full text-sm">
                          {course.level}
                        </span>
                        <div className="flex items-center text-yellow-400">
                          <Star className="h-4 w-4 fill-current" />
                          <span className="ml-1 text-sm">{course.rating}</span>
                        </div>
                      </div>
                      <h3 className="text-xl font-semibold text-white mb-2">
                        {course.title}
                      </h3>
                      <p className="text-primary-200 mb-4">
                        {course.description}
                      </p>
                      <div className="flex items-center text-primary-300 mb-4">
                        <Clock className="h-4 w-4 mr-2" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center text-primary-300 mb-6">
                        <Award className="h-4 w-4 mr-2" />
                        <span>{course.instructor}</span>
                      </div>
                      <div className="space-y-2">
                        <h4 className="text-sm font-semibold text-white">Inclus :</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex items-center text-primary-200">
                            <Video className="h-4 w-4 mr-2 text-secondary-400" />
                            <span>Vidéos HD</span>
                          </div>
                          <div className="flex items-center text-primary-200">
                            <FileText className="h-4 w-4 mr-2 text-secondary-400" />
                            <span>Resources</span>
                          </div>
                          <div className="flex items-center text-primary-200">
                            <MessageSquare className="h-4 w-4 mr-2 text-secondary-400" />
                            <span>Support</span>
                          </div>
                          <div className="flex items-center text-primary-200">
                            <Code className="h-4 w-4 mr-2 text-secondary-400" />
                            <span>Exercices</span>
                          </div>
                        </div>
                      </div>
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="mt-6 w-full px-6 py-3 bg-gradient-to-r from-secondary-500 to-primary-500 text-white rounded-full text-sm font-medium hover:opacity-90 transition-all duration-300 shadow-lg shadow-secondary-500/25"
                      >
                        Commencer la formation
                      </motion.button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 bg-primary-900/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white">
                Pourquoi choisir nos formations ?
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                {
                  icon: <Brain className="h-8 w-8" />,
                  title: "Expertise reconnue",
                  description: "Formateurs experts certifiés"
                },
                {
                  icon: <Cpu className="h-8 w-8" />,
                  title: "Pratique intensive",
                  description: "Exercices et cas réels"
                },
                {
                  icon: <Award className="h-8 w-8" />,
                  title: "Certification",
                  description: "Certification professionnelle"
                }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="inline-flex p-3 rounded-lg bg-secondary-500/10 text-secondary-400">
                    {feature.icon}
                  </div>
                  <h3 className="mt-4 text-lg font-medium text-white">
                    {feature.title}
                  </h3>
                  <p className="mt-2 text-primary-300">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Formation;